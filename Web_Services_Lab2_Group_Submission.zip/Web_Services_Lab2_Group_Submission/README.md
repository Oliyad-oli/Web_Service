# Web Services Lab Practice 2 - Group Submission Package

**Course:** Web Services (SEng-4112)  
**Academic Year:** 2026-2027 (Year V - Semester I)  
**Department:** Department of Software Engineering, Haramaya University  

## Group Members
1. Yabets Tinsae Dube (1040/15)
2. Tesfalem Markos (0993/15)
3. Abdi Tamene Tekuma (0008/15)
4. Yosan Gonfa Merga (1084/15)
5. Oliyad Dandena (1786/15)

## Package Contents
* `LAB_PRACTICE_2_REPORT_FINAL.pdf` - Complete comprehensive laboratory report (PDF format).
* `LAB_PRACTICE_2_REPORT_FINAL.md` - Source report in Markdown format.
* `LAB_PRACTICE_2_REPORT_FINAL.html` - Self-contained HTML report.
* `LAB-PRACTICE-2/EXPERIMENT-1-PHP/` - Experiment 1 PHP RESTful XML web service source code and SQL scripts.
* `LAB-PRACTICE-2/EXPERIMENT-2-JAVA/` - Experiment 2 Java Jakarta RESTful web service source code, Maven POM, and SQL scripts.
* `LAB-PRACTICE-2/test_all_endpoints.sh` - Automated regression test suite for both experiments.

## Quick Run Instructions
* Experiment 1: Open `http://localhost/experiment1/parts.php?vendor_id=1` in web browser or Postman.
* Experiment 2: Deploy WAR (`mvn clean package && sudo cp target/student-api.war /var/lib/tomcat10/webapps/`), then test `http://localhost:8080/student-api/students`.
* Run test suite: `./LAB-PRACTICE-2/test_all_endpoints.sh`
